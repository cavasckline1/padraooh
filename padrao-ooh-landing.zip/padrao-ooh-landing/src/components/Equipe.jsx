import React from 'react'
import { motion } from 'framer-motion'
import { Users, Award, Clock, Target } from 'lucide-react'
import teamImg from '../assets/team_collaboration.png'

const Equipe = () => {
  const stats = [
    {
      icon: Clock,
      number: "12+",
      label: "Anos de Experiência",
      description: "Décadas de conhecimento acumulado no mercado de mídia exterior"
    },
    {
      icon: Users,
      number: "100%",
      label: "Equipe Qualificada",
      description: "Profissionais especializados com passagem por grandes veículos"
    },
    {
      icon: Award,
      number: "Premium",
      label: "Atendimento",
      description: "Relacionamento próximo e personalizado com cada cliente"
    },
    {
      icon: Target,
      number: "Foco",
      label: "em Resultados",
      description: "Comprometimento total com o sucesso das suas campanhas"
    }
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6
      }
    }
  }

  return (
    <section id="equipe" className="section-padding bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Equipe <span className="text-gradient">Altamente Qualificada</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Nossa força está na experiência coletiva. Uma equipe de especialistas com anos 
            de atuação no mercado de mídia exterior, focada em entregar resultados excepcionais.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image Section */}
          <motion.div 
            className="relative"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="relative rounded-2xl overflow-hidden">
              <img 
                src={teamImg} 
                alt="Equipe Padrão OOH trabalhando em estratégias" 
                className="w-full h-auto rounded-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent"></div>
            </div>
            
            {/* Floating Card */}
            <motion.div 
              className="absolute -bottom-6 -right-6 bg-white rounded-xl p-6 shadow-2xl border border-border"
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              viewport={{ once: true }}
            >
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">12+</div>
                <div className="text-sm text-muted-foreground">Anos de Experiência</div>
              </div>
            </motion.div>
          </motion.div>

          {/* Content Section */}
          <motion.div 
            className="space-y-8"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.div variants={itemVariants}>
              <h3 className="text-2xl font-bold text-foreground mb-4">
                Experiência que Faz a Diferença
              </h3>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Nossa equipe é formada por profissionais que já atuaram em grandes veículos 
                de mídia exterior, trazendo conhecimento profundo do mercado brasileiro e 
                internacional. Cada membro contribui com sua expertise única para garantir 
                o sucesso das suas campanhas.
              </p>
            </motion.div>

            <motion.div variants={itemVariants}>
              <h4 className="text-xl font-semibold text-foreground mb-4">
                Nossos Valores
              </h4>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-secondary rounded-full mt-2 flex-shrink-0"></div>
                  <div>
                    <div className="font-semibold text-foreground">Transparência</div>
                    <div className="text-muted-foreground">Relacionamento claro e honesto em todas as negociações</div>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-accent rounded-full mt-2 flex-shrink-0"></div>
                  <div>
                    <div className="font-semibold text-foreground">Qualidade</div>
                    <div className="text-muted-foreground">Padrão de excelência em todos os processos e entregas</div>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                  <div>
                    <div className="font-semibold text-foreground">Relacionamento</div>
                    <div className="text-muted-foreground">Foco em criar parcerias duradouras e de valor</div>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div 
              variants={itemVariants}
              className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-xl p-6"
            >
              <div className="flex items-center space-x-3 mb-3">
                <Award className="h-6 w-6 text-secondary" />
                <h4 className="text-lg font-semibold text-foreground">Compromisso com Resultados</h4>
              </div>
              <p className="text-muted-foreground">
                Não somos apenas fornecedores, somos parceiros estratégicos. Nossa equipe 
                trabalha como uma extensão do seu time, sempre focada em superar expectativas 
                e entregar resultados mensuráveis.
              </p>
            </motion.div>
          </motion.div>
        </div>

        {/* Stats Grid */}
        <motion.div 
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mt-20"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {stats.map((stat, index) => {
            const IconComponent = stat.icon
            return (
              <motion.div
                key={index}
                variants={itemVariants}
                className="text-center group"
              >
                <div className="bg-card rounded-2xl p-8 border border-border card-hover">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/10 to-secondary/10 mb-6 group-hover:scale-110 transition-transform duration-300">
                    <IconComponent className="h-8 w-8 text-primary" />
                  </div>
                  
                  <div className="text-3xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                    {stat.number}
                  </div>
                  
                  <div className="text-lg font-semibold text-foreground mb-3">
                    {stat.label}
                  </div>
                  
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {stat.description}
                  </p>
                </div>
              </motion.div>
            )
          })}
        </motion.div>
      </div>
    </section>
  )
}

export default Equipe

