import React from 'react'
import { motion } from 'framer-motion'
import { 
  Target, 
  Shield, 
  DollarSign, 
  Camera, 
  BarChart3, 
  FileText,
  ArrowRight 
} from 'lucide-react'
import { Button } from '@/components/ui/button'

const Servicos = () => {
  const servicos = [
    {
      icon: Target,
      title: "Planejamento Estratégico",
      description: "Análise completa do mercado e definição de estratégias personalizadas para maximizar o impacto da sua campanha de mídia exterior.",
      features: ["Análise de público-alvo", "Estudo de mercado", "Definição de KPIs", "Estratégia de posicionamento"]
    },
    {
      icon: Shield,
      title: "Qualificação de Veículos",
      description: "Avaliação rigorosa de veículos e ativos com nosso sistema exclusivo de selos Bronze, Prata e Ouro.",
      features: ["Auditoria técnica", "Certificação de qualidade", "Análise de localização", "Validação de audiência"]
    },
    {
      icon: DollarSign,
      title: "Negociação e Compra de Mídia",
      description: "Negociações estratégicas para garantir os melhores custos sem comprometer a qualidade da entrega.",
      features: ["Negociação de preços", "Otimização de investimento", "Contratos transparentes", "Gestão de prazos"]
    },
    {
      icon: Camera,
      title: "Checking Fotográfico",
      description: "Padrão técnico fotográfico profissional para documentar e garantir a qualidade de todas as instalações.",
      features: ["Fotos padronizadas", "Relatórios visuais", "Controle de qualidade", "Documentação completa"]
    },
    {
      icon: BarChart3,
      title: "Gestão de Campanhas",
      description: "Acompanhamento completo desde o planejamento até a execução, garantindo que tudo saia conforme planejado.",
      features: ["Monitoramento 24/7", "Gestão de cronograma", "Controle de qualidade", "Suporte dedicado"]
    },
    {
      icon: FileText,
      title: "Relatórios de Performance",
      description: "Análises detalhadas e relatórios completos sobre o desempenho e resultados das suas campanhas.",
      features: ["Métricas de alcance", "Análise de ROI", "Relatórios personalizados", "Insights estratégicos"]
    }
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15
      }
    }
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6
      }
    }
  }

  return (
    <section id="servicos" className="section-padding bg-background">
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Nossos <span className="text-gradient">Serviços</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Oferecemos uma gama completa de soluções em mídia exterior, desde o planejamento 
            estratégico até a entrega final, sempre com foco na qualidade e resultados.
          </p>
        </motion.div>

        <motion.div 
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {servicos.map((servico, index) => {
            const IconComponent = servico.icon
            return (
              <motion.div
                key={index}
                variants={itemVariants}
                className="group"
              >
                <div className="bg-card rounded-2xl p-8 h-full border border-border card-hover">
                  <div className="flex items-center mb-6">
                    <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-gradient-to-br from-primary/10 to-secondary/10 mr-4 group-hover:scale-110 transition-transform duration-300">
                      <IconComponent className="h-7 w-7 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold text-foreground group-hover:text-primary transition-colors">
                      {servico.title}
                    </h3>
                  </div>
                  
                  <p className="text-muted-foreground mb-6 leading-relaxed">
                    {servico.description}
                  </p>

                  <ul className="space-y-2">
                    {servico.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center text-sm text-muted-foreground">
                        <div className="w-1.5 h-1.5 bg-secondary rounded-full mr-3 flex-shrink-0"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <div className="mt-6 pt-6 border-t border-border">
                    <button className="text-primary hover:text-primary/80 font-semibold text-sm flex items-center group-hover:translate-x-1 transition-transform">
                      Saiba mais
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </button>
                  </div>
                </div>
              </motion.div>
            )
          })}
        </motion.div>

        {/* Process Flow */}
        <motion.div 
          className="mt-20"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-foreground mb-4">
              Como Trabalhamos
            </h3>
            <p className="text-lg text-muted-foreground">
              Nosso processo estruturado garante excelência em cada etapa
            </p>
          </div>

          <div className="grid md:grid-cols-5 gap-8">
            {[
              { step: "01", title: "Análise", desc: "Entendemos seu negócio e objetivos" },
              { step: "02", title: "Planejamento", desc: "Desenvolvemos estratégia personalizada" },
              { step: "03", title: "Qualificação", desc: "Selecionamos os melhores veículos" },
              { step: "04", title: "Execução", desc: "Implementamos com qualidade" },
              { step: "05", title: "Relatórios", desc: "Entregamos resultados mensuráveis" }
            ].map((item, index) => (
              <motion.div 
                key={index}
                className="text-center relative"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center text-white font-bold text-lg mx-auto mb-4">
                  {item.step}
                </div>
                <h4 className="font-semibold text-foreground mb-2">{item.title}</h4>
                <p className="text-sm text-muted-foreground">{item.desc}</p>
                
                {index < 4 && (
                  <div className="hidden md:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-primary/50 to-secondary/50 transform -translate-y-1/2"></div>
                )}
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* CTA */}
        <motion.div 
          className="text-center mt-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <Button 
            size="lg"
            onClick={() => {
              const element = document.getElementById('contato')
              if (element) element.scrollIntoView({ behavior: 'smooth' })
            }}
            className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 text-lg font-semibold"
          >
            Solicitar Proposta Personalizada
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </motion.div>
      </div>
    </section>
  )
}

export default Servicos

