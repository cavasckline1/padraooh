import React from 'react'
import { motion } from 'framer-motion'
import { 
  Search, 
  Shield, 
  Handshake, 
  Play, 
  BarChart3,
  ArrowRight,
  CheckCircle 
} from 'lucide-react'

const Processo = () => {
  const etapas = [
    {
      icon: Search,
      number: "01",
      title: "Análise e Planejamento",
      description: "Entendemos profundamente seu negócio, objetivos e público-alvo para desenvolver uma estratégia personalizada.",
      details: [
        "Briefing detalhado com o cliente",
        "Análise do mercado e concorrência",
        "Definição de objetivos e KPIs",
        "Estudo do público-alvo"
      ],
      color: "from-blue-500 to-blue-600"
    },
    {
      icon: Shield,
      number: "02",
      title: "Qualificação de Veículos",
      description: "Aplicamos nosso sistema exclusivo de selos para avaliar e certificar a qualidade dos veículos e ativos.",
      details: [
        "Auditoria técnica completa",
        "Análise de localização e fluxo",
        "Certificação Bronze, Prata ou Ouro",
        "Validação de audiência"
      ],
      color: "from-amber-500 to-amber-600"
    },
    {
      icon: Handshake,
      number: "03",
      title: "Negociação Estratégica",
      description: "Utilizamos nossa experiência e relacionamentos para garantir os melhores custos e condições.",
      details: [
        "Negociação de preços competitivos",
        "Otimização do investimento",
        "Contratos transparentes",
        "Condições comerciais favoráveis"
      ],
      color: "from-green-500 to-green-600"
    },
    {
      icon: Play,
      number: "04",
      title: "Execução e Monitoramento",
      description: "Implementamos a campanha com rigor técnico e acompanhamos cada etapa para garantir a qualidade.",
      details: [
        "Gestão completa da implementação",
        "Checking fotográfico padronizado",
        "Monitoramento em tempo real",
        "Suporte técnico dedicado"
      ],
      color: "from-purple-500 to-purple-600"
    },
    {
      icon: BarChart3,
      number: "05",
      title: "Relatórios e Otimização",
      description: "Entregamos análises detalhadas dos resultados e insights para otimização contínua.",
      details: [
        "Relatórios de performance",
        "Análise de ROI e métricas",
        "Insights estratégicos",
        "Recomendações de otimização"
      ],
      color: "from-red-500 to-red-600"
    }
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  }

  const itemVariants = {
    hidden: { opacity: 0, x: -50 },
    visible: {
      opacity: 1,
      x: 0,
      transition: {
        duration: 0.6
      }
    }
  }

  return (
    <section id="processo" className="section-padding bg-background">
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Como <span className="text-gradient">Trabalhamos</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Nosso processo estruturado e comprovado garante excelência em cada etapa, 
            desde o primeiro contato até a entrega dos resultados finais.
          </p>
        </motion.div>

        <motion.div 
          className="space-y-12"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {etapas.map((etapa, index) => {
            const IconComponent = etapa.icon
            const isEven = index % 2 === 0
            
            return (
              <motion.div
                key={index}
                variants={itemVariants}
                className={`grid lg:grid-cols-2 gap-12 items-center ${!isEven ? 'lg:grid-flow-col-dense' : ''}`}
              >
                {/* Content */}
                <div className={`space-y-6 ${!isEven ? 'lg:col-start-2' : ''}`}>
                  <div className="flex items-center space-x-4">
                    <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${etapa.color} flex items-center justify-center text-white font-bold text-xl`}>
                      {etapa.number}
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-foreground">{etapa.title}</h3>
                      <div className="flex items-center space-x-2 mt-1">
                        <IconComponent className="h-5 w-5 text-primary" />
                        <span className="text-sm text-muted-foreground">Etapa {etapa.number}</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-lg text-muted-foreground leading-relaxed">
                    {etapa.description}
                  </p>

                  <div className="space-y-3">
                    {etapa.details.map((detail, detailIndex) => (
                      <motion.div 
                        key={detailIndex}
                        className="flex items-center space-x-3"
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.4, delay: detailIndex * 0.1 }}
                        viewport={{ once: true }}
                      >
                        <CheckCircle className="h-5 w-5 text-accent flex-shrink-0" />
                        <span className="text-muted-foreground">{detail}</span>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Visual Element */}
                <div className={`relative ${!isEven ? 'lg:col-start-1 lg:row-start-1' : ''}`}>
                  <motion.div 
                    className="relative"
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.6, delay: 0.2 }}
                    viewport={{ once: true }}
                  >
                    <div className={`w-80 h-80 mx-auto rounded-3xl bg-gradient-to-br ${etapa.color} opacity-10`}></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className={`w-32 h-32 rounded-2xl bg-gradient-to-br ${etapa.color} flex items-center justify-center shadow-2xl`}>
                        <IconComponent className="h-16 w-16 text-white" />
                      </div>
                    </div>
                    
                    {/* Floating Elements */}
                    <div className="absolute top-4 right-4 w-8 h-8 bg-secondary rounded-full animate-float"></div>
                    <div className="absolute bottom-8 left-8 w-6 h-6 bg-accent rounded-full animate-float" style={{ animationDelay: '1s' }}></div>
                    <div className="absolute top-1/2 left-4 w-4 h-4 bg-primary rounded-full animate-float" style={{ animationDelay: '2s' }}></div>
                  </motion.div>
                </div>

                {/* Connection Line */}
                {index < etapas.length - 1 && (
                  <div className="hidden lg:block col-span-2 flex justify-center my-8">
                    <div className="w-px h-16 bg-gradient-to-b from-border to-transparent"></div>
                    <ArrowRight className="h-6 w-6 text-muted-foreground transform rotate-90 -mt-3" />
                  </div>
                )}
              </motion.div>
            )
          })}
        </motion.div>

        {/* Summary */}
        <motion.div 
          className="mt-20 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <div className="bg-gradient-to-r from-primary/5 to-secondary/5 rounded-2xl p-8 border border-border">
            <h3 className="text-2xl font-bold text-foreground mb-4">
              Processo Comprovado, Resultados Garantidos
            </h3>
            <p className="text-lg text-muted-foreground mb-6 max-w-2xl mx-auto">
              Cada etapa do nosso processo foi desenvolvida com base em anos de experiência 
              no mercado, garantindo que sua campanha tenha o máximo de eficiência e impacto.
            </p>
            <button 
              onClick={() => {
                const element = document.getElementById('contato')
                if (element) element.scrollIntoView({ behavior: 'smooth' })
              }}
              className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-3 rounded-lg font-semibold transition-colors inline-flex items-center"
            >
              Iniciar Meu Projeto
              <ArrowRight className="ml-2 h-5 w-5" />
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default Processo

