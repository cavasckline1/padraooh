import React from 'react'
import { motion } from 'framer-motion'
import { 
  Mail, 
  Phone, 
  MapPin, 
  Linkedin, 
  Instagram, 
  Facebook,
  ArrowUp 
} from 'lucide-react'
import logoImg from '../assets/padrao_ooh_logo.png'

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-primary text-primary-foreground">
      {/* Main Footer */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-8">
          {/* Company Info */}
          <motion.div 
            className="lg:col-span-2"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center space-x-3 mb-6">
              <img src={logoImg} alt="Padrão OOH" className="h-12 w-auto brightness-0 invert" />
            </div>
            <p className="text-lg text-primary-foreground/80 mb-6 max-w-md">
              Excelência em mídia exterior com equipe especializada e sistema exclusivo 
              de qualificação. Transformamos campanhas em resultados excepcionais.
            </p>
            
            {/* Contact Info */}
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-secondary" />
                <span>contato@padraoooh.com.br</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-secondary" />
                <span>+55 (11) 99999-9999</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-secondary" />
                <span>São Paulo, SP - Atendimento Nacional</span>
              </div>
            </div>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xl font-bold mb-6">Links Rápidos</h3>
            <ul className="space-y-3">
              <li>
                <button 
                  onClick={() => scrollToSection('sobre')}
                  className="text-primary-foreground/80 hover:text-secondary transition-colors"
                >
                  Sobre Nós
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('servicos')}
                  className="text-primary-foreground/80 hover:text-secondary transition-colors"
                >
                  Serviços
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('diferenciais')}
                  className="text-primary-foreground/80 hover:text-secondary transition-colors"
                >
                  Diferenciais
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('equipe')}
                  className="text-primary-foreground/80 hover:text-secondary transition-colors"
                >
                  Equipe
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('contato')}
                  className="text-primary-foreground/80 hover:text-secondary transition-colors"
                >
                  Contato
                </button>
              </li>
            </ul>
          </motion.div>

          {/* Services */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xl font-bold mb-6">Nossos Serviços</h3>
            <ul className="space-y-3">
              <li className="text-primary-foreground/80">Planejamento Estratégico</li>
              <li className="text-primary-foreground/80">Qualificação de Veículos</li>
              <li className="text-primary-foreground/80">Negociação de Mídia</li>
              <li className="text-primary-foreground/80">Checking Fotográfico</li>
              <li className="text-primary-foreground/80">Gestão de Campanhas</li>
              <li className="text-primary-foreground/80">Relatórios de Performance</li>
            </ul>
          </motion.div>
        </div>

        {/* Social Media & CTA */}
        <motion.div 
          className="border-t border-primary-foreground/20 mt-12 pt-8"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <div className="flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0">
            <div>
              <h4 className="text-lg font-semibold mb-3">Siga-nos nas Redes Sociais</h4>
              <div className="flex space-x-4">
                <a 
                  href="#" 
                  className="w-10 h-10 bg-primary-foreground/10 rounded-lg flex items-center justify-center hover:bg-secondary transition-colors"
                >
                  <Linkedin className="h-5 w-5" />
                </a>
                <a 
                  href="#" 
                  className="w-10 h-10 bg-primary-foreground/10 rounded-lg flex items-center justify-center hover:bg-secondary transition-colors"
                >
                  <Instagram className="h-5 w-5" />
                </a>
                <a 
                  href="#" 
                  className="w-10 h-10 bg-primary-foreground/10 rounded-lg flex items-center justify-center hover:bg-secondary transition-colors"
                >
                  <Facebook className="h-5 w-5" />
                </a>
              </div>
            </div>

            <div className="text-center md:text-right">
              <p className="text-primary-foreground/80 mb-3">
                Pronto para começar seu projeto?
              </p>
              <button 
                onClick={() => scrollToSection('contato')}
                className="bg-secondary hover:bg-secondary/90 text-secondary-foreground px-6 py-3 rounded-lg font-semibold transition-colors"
              >
                Solicitar Proposta
              </button>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-primary-foreground/20">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-center md:text-left">
              <p className="text-primary-foreground/60 text-sm">
                © {currentYear} Padrão OOH. Todos os direitos reservados.
              </p>
              <p className="text-primary-foreground/60 text-sm">
                Desenvolvido com excelência para mídia exterior.
              </p>
            </div>

            <div className="flex items-center space-x-6">
              <a href="#" className="text-primary-foreground/60 hover:text-secondary text-sm transition-colors">
                Política de Privacidade
              </a>
              <a href="#" className="text-primary-foreground/60 hover:text-secondary text-sm transition-colors">
                Termos de Uso
              </a>
              <button 
                onClick={scrollToTop}
                className="w-10 h-10 bg-primary-foreground/10 rounded-lg flex items-center justify-center hover:bg-secondary transition-colors group"
              >
                <ArrowUp className="h-5 w-5 group-hover:-translate-y-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer

